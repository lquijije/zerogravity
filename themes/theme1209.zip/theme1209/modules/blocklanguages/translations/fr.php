<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocklanguages}prestashop>blocklanguages_d5988791c07fedc0e2fc77683b4e61f6'] = 'Bloc langues';
$_MODULE['<{blocklanguages}prestashop>blocklanguages_5bc2cbadb5e09b5ef9b9d1724072c4f9'] = 'Ajoute un bloc permettant à vos clients de sélectionner la langue de votre boutique.';


return $_MODULE;
