<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_a2e9cd952cda8ba167e62b25a496c6c1'] = 'Блок информации о пользователе';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_970a31aa19d205f92ccfd1913ca04dc0'] = 'Добавляет блок, отображающий информацию о клиенте.';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_0c3bf3014aafb90201805e45b5e62881'] = 'Просмотр корзины';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_a85eba4c6c699122b2bb1387ea4813ad'] = 'Корзина';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_deb10517653c255364175796ace3553f'] = 'товар';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_068f80c7519d0528fb08e82137a72131'] = 'Товары';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_9e65b51e82f2a9b9f72ebe3e083582bb'] = '(пусто)';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_2cbfb6731610056e1d0aaacde07096c1'] = 'Просмотреть мою учетную запись';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_a0623b78a5f2cfe415d9dbbd4428ea40'] = 'Ваша учетная запись';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_83218ac34c1834c26781fe4bde918ee4'] = 'Добро пожаловать';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_4b877ba8588b19f1b278510bf2b57ebb'] = 'Выйти';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_c87aacf5673fada1108c9f809d354311'] = 'Выход';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_d4151a9a3959bdd43690735737034f27'] = 'Войти в учетную запись';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_b6d4223e60986fa4c9af77ee5f7149c5'] = 'Войти';
$_MODULE['<{blockuserinfo}prestashop>nav_2cbfb6731610056e1d0aaacde07096c1'] = 'Просмотреть мою учетную запись';
$_MODULE['<{blockuserinfo}prestashop>nav_4b877ba8588b19f1b278510bf2b57ebb'] = 'Выйти';
$_MODULE['<{blockuserinfo}prestashop>nav_c87aacf5673fada1108c9f809d354311'] = 'Выход';
$_MODULE['<{blockuserinfo}prestashop>nav_d4151a9a3959bdd43690735737034f27'] = 'Войти в учетную запись';
$_MODULE['<{blockuserinfo}prestashop>nav_b6d4223e60986fa4c9af77ee5f7149c5'] = 'Войти';


return $_MODULE;
