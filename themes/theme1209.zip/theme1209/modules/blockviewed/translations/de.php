<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockviewed}prestashop>blockviewed_859e85774d372c6084d62d02324a1cc3'] = 'Block Angesehene Produkte';
$_MODULE['<{blockviewed}prestashop>blockviewed_eaa362292272519b786c2046ab4b68d2'] = 'Fügt einen Block hinzu, der die zuletzt angesehenen Artikel anzeigt';
$_MODULE['<{blockviewed}prestashop>blockviewed_2e57399079951d84b435700493b8a8c1'] = 'Sie müssen das Feld "Anzuzeigende Artikel" ausfüllen.';
$_MODULE['<{blockviewed}prestashop>blockviewed_73293a024e644165e9bf48f270af63a0'] = 'Ungültige Anzahl';
$_MODULE['<{blockviewed}prestashop>blockviewed_f38f5974cdc23279ffe6d203641a8bdf'] = 'Einstellungen aktualisiert.';
$_MODULE['<{blockviewed}prestashop>blockviewed_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blockviewed}prestashop>blockviewed_26986c3388870d4148b1b5375368a83d'] = 'Anzuzeigende Artikel';
$_MODULE['<{blockviewed}prestashop>blockviewed_d36bbb6066e3744039d38e580f17a2cc'] = 'Legen Sie die Anzahl der Artikel fest, die in diesem Block angezeigt werden.';
$_MODULE['<{blockviewed}prestashop>blockviewed_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{blockviewed}prestashop>blockviewed_43560641f91e63dc83682bc598892fa1'] = 'Angesehene Artikel';
$_MODULE['<{blockviewed}prestashop>blockviewed_8f7f4c1ce7a4f933663d10543562b096'] = 'Nähere Infos';
$_MODULE['<{blockviewed}prestashop>blockviewed_c70ad5f80e4c6f299013e08cabc980df'] = 'Mehr über %s';


return $_MODULE;
